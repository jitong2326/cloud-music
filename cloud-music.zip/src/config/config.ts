// 接口api地址常量
export const URL = {
  musicUrl: 'http://localhost:4000'
}
// 全局常量
export const CT = {
  timeout: 10000
}
