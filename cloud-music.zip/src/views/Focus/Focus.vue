<template>
  <div class="home-container">
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
    <h1>Focus</h1>
  </div>
</template>

<style lang="less" scoped>
.home-container {
  width: 100%;
  height: calc(100vh - 120px);
  overflow-y: scroll;
  h1 {
    color: @themeColor
  }
}
</style>
